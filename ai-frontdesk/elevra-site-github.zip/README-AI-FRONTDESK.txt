ELEVRA SITE (GitHub Pages ready, no build step)

  /index.html               link-in-bio (3D) — button "SEE AI FRONTDESK" → /ai-frontdesk/
  /diagnostic/index.html    AI Sales Diagnostic $97
  /ai-frontdesk/index.html  AI Frontdesk landing v2 (EN/PT/ES)   ← UPDATED
  /og-frontdesk.png         social image (violet, "Never miss another opportunity")   ← UPDATED
  /og-diagnostic.png        social image for /diagnostic/

AI FRONTDESK v2 — WHERE THINGS LIVE (inside /ai-frontdesk/index.html, bottom <script>)

  ELEVRA_CONFIG
    demoUrl      ← paste the demo/booking link here. Every BOOK A DEMO / GET STARTED uses it.
    salesUrl     ← optional link for TALK TO SALES / TALK TO OUR TEAM (falls back to demoUrl)
    contactUrl   ← shown inside the "TEMPORARY CONTACT" modal while the URLs above are empty
    defaultTerm  ← "m6" (6 months opens selected). Other values: monthly | m3 | annual
    plans        ← all prices, setup fees and minute allowances per plan and term

  CTA routing    configured URL → temporary modal. Never "#".

  Translations   const translations = { en, pt, es } — text via data-i18n, attributes via
                 data-i18n-attr. Plans and FAQ render from the same dictionary.
                 localStorage["elevra_lang"] persists the choice; <html lang> updates.

  trackEvent(name, data) → window.dataLayer (console log only when window.ELEVRA_DEBUG = true)
    ai_frontdesk_page_view, language_changed, pricing_view, pricing_term_changed,
    demo_cta_click {place, plan, term}, sales_cta_click, roi_calculator_used, faq_opened

  Social proof   <section id="proof" hidden data-placeholder="social-proof"> — fill the
                 [CALL VOLUME] / [APPOINTMENTS] / [RESPONSE RATE] / [OPPORTUNITIES] placeholders
                 with real data and remove `hidden`. Nothing fabricated.

  ROI formula    missed calls/week × 4.33 × conversion% × customer value = monthly estimate
